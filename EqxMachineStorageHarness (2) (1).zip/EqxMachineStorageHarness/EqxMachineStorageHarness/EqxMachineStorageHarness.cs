﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DemandModifierLib;
using HardwareInterfaceLib;

namespace EqxMachineStorageHarness
{
    public partial class EqxMachineStorageHarness : Form
    {

        private DemandModifierInterface m_DMInterfacexyzToHexapod;
        private DemandModifierInterface m_DMInterfaceStrutErrorMapDM1;
        private DemandModifierInterface m_DMInterfaceStrutErrorMapDM2;
        private DemandModifierInterface m_DMInterfaceStrutErrorMapDM3;
        private DemandModifierInterface m_DMInterfaceStrutErrorMapDM4;
        private DemandModifierInterface m_DMInterfaceStrutErrorMapDM5;
        private DemandModifierInterface m_DMInterfaceStrutErrorMapDM6;
        private DemandModifierInterface m_DMInterfaceScorpioPositionCorrection;

        private HardwareInterfaceInterface m_HWInterfaceHubEEPROM;

        public EqxMachineStorageHarness()
        {
            InitializeComponent();
            m_DMInterfacexyzToHexapod = new DemandModifierInterface();
            m_DMInterfaceStrutErrorMapDM1 = new DemandModifierInterface();
            m_DMInterfaceStrutErrorMapDM2 = new DemandModifierInterface();
            m_DMInterfaceStrutErrorMapDM3 = new DemandModifierInterface();
            m_DMInterfaceStrutErrorMapDM4 = new DemandModifierInterface();
            m_DMInterfaceStrutErrorMapDM5 = new DemandModifierInterface();
            m_DMInterfaceStrutErrorMapDM6 = new DemandModifierInterface();
            m_DMInterfaceScorpioPositionCorrection = new DemandModifierInterface();

            m_HWInterfaceHubEEPROM = new HardwareInterfaceInterface();

            m_DMInterfacexyzToHexapod.ServerClosed += new _IDemandModifierInterfaceEvents_ServerClosedEventHandler(m_DMInterface_ServerClosed);
            clsIPAddress.GetAddresses(ref cmbControllerID);
        }

        private void m_DMInterface_ServerClosed()
        {
            MessageBox.Show("The Controller Has Closed the Connection");
        }

        private void cmdConnect_Click(object sender, EventArgs e)
        {
            try
            {
                m_DMInterfacexyzToHexapod.Connect(cmbControllerID.Text, "xyzToHexapodDM", "xyzToHexapodDM");
                m_DMInterfaceStrutErrorMapDM1.Connect(cmbControllerID.Text, "StrutErrorMapDM1", "StrutErrorMapDM");
                m_DMInterfaceStrutErrorMapDM2.Connect(cmbControllerID.Text, "StrutErrorMapDM2", "StrutErrorMapDM");
                m_DMInterfaceStrutErrorMapDM3.Connect(cmbControllerID.Text, "StrutErrorMapDM3", "StrutErrorMapDM");
                m_DMInterfaceStrutErrorMapDM4.Connect(cmbControllerID.Text, "StrutErrorMapDM4", "StrutErrorMapDM");
                m_DMInterfaceStrutErrorMapDM5.Connect(cmbControllerID.Text, "StrutErrorMapDM5", "StrutErrorMapDM");
                m_DMInterfaceStrutErrorMapDM6.Connect(cmbControllerID.Text, "StrutErrorMapDM6", "StrutErrorMapDM");
                m_DMInterfaceScorpioPositionCorrection.Connect(cmbControllerID.Text, "ScorpioPositionCorrectionDM", "ScorpioPositionCorrectionDM");

                m_HWInterfaceHubEEPROM.Connect(cmbControllerID.Text, "HubEEPROMInterface", "HubEEPROMInterface");

                clsIPAddress.SetIPValue(cmbControllerID.Text);
                btnConnect.BackColor = Color.FromArgb(0, 192, 0);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + " - cannot connect to controller: " + cmbControllerID.Text);
            }

        }

        private void WriteToHUB_StrutOffset(object sender, EventArgs e)
        {
            int Strut1OffsetParamNum = 3;
            int Strut2OffsetParamNum = 3;
            int Strut3OffsetParamNum = 3;
            int Strut4OffsetParamNum = 3;
            int Strut5OffsetParamNum = 3;
            int Strut6OffsetParamNum = 3;

            try
            {
                EDMReturnCode Return = m_DMInterfaceStrutErrorMapDM1.SetParameter(Strut1OffsetParamNum, Convert.ToDouble(txtStrut1Offset.Text));
                if (Return != EDMReturnCode.DM_SUCCESS)
                {
                    MessageBox.Show("Parameter Setting Failed In Strut1 StrutOffset: " + Return.ToString());
                    txtStrut1Offset.Text = Return.ToString();
                    //return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("In Strut1 StrutOffset " + ex.Message);
                //return;
            }

            try
            {
                EDMReturnCode Return = m_DMInterfaceStrutErrorMapDM2.SetParameter(Strut2OffsetParamNum, Convert.ToDouble(txtStrut2Offset.Text));
                if (Return != EDMReturnCode.DM_SUCCESS)
                {
                    MessageBox.Show("Parameter Setting Failed In Strut2 StrutOffset: " + Return.ToString());
                    txtStrut2Offset.Text = Return.ToString();
                    //return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("In Strut2 StrutOffset " + ex.Message);
                //return;
            }

            try
            {
                EDMReturnCode Return = m_DMInterfaceStrutErrorMapDM3.SetParameter(Strut3OffsetParamNum, Convert.ToDouble(txtStrut3Offset.Text));
                if (Return != EDMReturnCode.DM_SUCCESS)
                {
                    MessageBox.Show("Parameter Setting Failed In Strut3 StrutOffset: " + Return.ToString());
                    txtStrut3Offset.Text = Return.ToString();
                    //return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("In Strut3 StrutOffset " + ex.Message);
                //return;
            }

            try
            {
                EDMReturnCode Return = m_DMInterfaceStrutErrorMapDM4.SetParameter(Strut4OffsetParamNum, Convert.ToDouble(txtStrut4Offset.Text));
                if (Return != EDMReturnCode.DM_SUCCESS)
                {
                    MessageBox.Show("Parameter Setting Failed In Strut4 StrutOffset: " + Return.ToString());
                    txtStrut4Offset.Text = Return.ToString();
                    //return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("In Strut4 StrutOffset " + ex.Message);
                //return;
            }

            try
            {
                EDMReturnCode Return = m_DMInterfaceStrutErrorMapDM5.SetParameter(Strut5OffsetParamNum, Convert.ToDouble(txtStrut5Offset.Text));
                if (Return != EDMReturnCode.DM_SUCCESS)
                {
                    MessageBox.Show("Parameter Setting Failed In Strut5 StrutOffset: " + Return.ToString());
                    txtStrut5Offset.Text = Return.ToString();
                    //return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("In Strut5 StrutOffset " + ex.Message);
                //return;
            }

            try
            {
                EDMReturnCode Return = m_DMInterfaceStrutErrorMapDM6.SetParameter(Strut6OffsetParamNum, Convert.ToDouble(txtStrut6Offset.Text));
                if (Return != EDMReturnCode.DM_SUCCESS)
                {
                    MessageBox.Show("Parameter Setting Failed In Strut6 StrutOffset: " + Return.ToString());
                    txtStrut6Offset.Text = Return.ToString();
                    //return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("In Strut6 StrutOffset " + ex.Message);
                //return;
            }
        }

        private void WriteToHUB_StrutSlope(object sender, EventArgs e)
        {
            int Count = 1;
            int StrutSlopeParamNum = 4;
            string StrutName = "Strut" + Count.ToString();
            TextBox StrutSlopeTextBoxName = txtStrut1Slope;
            DemandModifierInterface m_DMInterface = m_DMInterfaceStrutErrorMapDM1;

            for (; Count <= 6; Count++) // All 6 struts
            {
                StrutName = "Strut" + Count.ToString();

                switch (Count)
                {
                    case 1: StrutSlopeTextBoxName = txtStrut1Slope;
                        m_DMInterface = m_DMInterfaceStrutErrorMapDM1;
                        break;
                    case 2: StrutSlopeTextBoxName = txtStrut2Slope;
                        m_DMInterface = m_DMInterfaceStrutErrorMapDM2;
                        break;
                    case 3: StrutSlopeTextBoxName = txtStrut3Slope;
                        m_DMInterface = m_DMInterfaceStrutErrorMapDM3;
                        break;
                    case 4: StrutSlopeTextBoxName = txtStrut4Slope;
                        m_DMInterface = m_DMInterfaceStrutErrorMapDM4;
                        break;
                    case 5: StrutSlopeTextBoxName = txtStrut5Slope;
                        m_DMInterface = m_DMInterfaceStrutErrorMapDM5;
                        break;
                    case 6: StrutSlopeTextBoxName = txtStrut6Slope;
                        m_DMInterface = m_DMInterfaceStrutErrorMapDM6;
                        break;
                }

                if ((StrutSlopeTextBoxName.Text == null) || (StrutSlopeTextBoxName.Text == ""))
                {
                    continue;
                }

                try
                {
                    EDMReturnCode Return = m_DMInterface.SetParameter(StrutSlopeParamNum, Convert.ToDouble(StrutSlopeTextBoxName.Text));
                    if (Return != EDMReturnCode.DM_SUCCESS)
                    {
                        MessageBox.Show("Parameter Setting Failed In " + StrutName + " StrutSlope : " + Return.ToString());
                        StrutSlopeTextBoxName.Text = Return.ToString();
                        //Application.Exit();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("In " + StrutName + " StrutSlope : " + ex.Message);
                    Environment.Exit(0);
                }

            }
        }

        private void WriteToHUB_StrutSerialNum(object sender, EventArgs e)
        {
            int Count = 1;
            int StrutSerialNumParamID = 10;
            string StrutName = "Strut" + Count.ToString();
            RichTextBox StrutSerialNumTextBoxName = txtStrut1SerialNum;

            for (; Count <= 6; Count++, StrutSerialNumParamID++) // All 6 struts
            {
                StrutName = "Strut" + Count.ToString();

                switch (Count)
                {
                    case 1: StrutSerialNumTextBoxName = txtStrut1SerialNum;
                        break;
                    case 2: StrutSerialNumTextBoxName = txtStrut2SerialNum;
                        break;
                    case 3: StrutSerialNumTextBoxName = txtStrut3SerialNum;
                        break;
                    case 4: StrutSerialNumTextBoxName = txtStrut4SerialNum;
                        break;
                    case 5: StrutSerialNumTextBoxName = txtStrut5SerialNum;
                        break;
                    case 6: StrutSerialNumTextBoxName = txtStrut6SerialNum;
                        break;
                }

                if ((StrutSerialNumTextBoxName.Text == null) || (StrutSerialNumTextBoxName.Text == ""))
                {
                    continue;
                }

                try
                {
                    if (StrutSerialNumTextBoxName.Text.Length == 6)
                    {
                        EHIReturnCode Return = m_HWInterfaceHubEEPROM.SetParameter(StrutSerialNumParamID, StrutSerialNumTextBoxName.Text);
                        if (Return != EHIReturnCode.HI_SUCCESS)
                        {
                            //MessageBox.Show("Parameter Setting Failed In " + StrutName + " StrutSerial Number : " + Return.ToString());
                            StrutSerialNumTextBoxName.Text = Return.ToString();
                            //Application.Exit();
                        }
                    }
                    else
                    {
                        //MessageBox.Show("Invalid Parameter. Setting Failed In " + StrutName + " StrutSerial Number : ");
                        StrutSerialNumTextBoxName.Text = "INVALID";
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("In " + StrutName + " StrutSerial Number : " + ex.Message);
                    Environment.Exit(0);
                }
            }
        }

        private void WriteToHUB_SquareComp(object sender, EventArgs e)
        {
            try
            {
                object Param = null;
                int SquareCompParamID = 20010;
                TextBox SqCompRow = txtSquareCompR0;
                short NumItems = 9;
                string[] RowSplit;

                double[] doubleArray = new double[NumItems];

                for (var i = 0; i <= 2; i++)
                {
                    switch (i)
                    {
                        case 0:
                            SqCompRow = txtSquareCompR0;
                            break;
                        case 1:
                            SqCompRow = txtSquareCompR1;
                            break;
                        case 2:
                            SqCompRow = txtSquareCompR2;
                            break;
                    }

                    if ((SqCompRow.Text == null) || (SqCompRow.Text == ""))
                    {
                        MessageBox.Show("A row of SquarenessComp is NULL");
                        return;
                    }

                    RowSplit = SqCompRow.Text.Split(':');
                    if (RowSplit.Length != 3)
                    {
                        MessageBox.Show("Some invalid data for SquarenessComp");
                        return;
                    }
                    for (var j = 0; j < RowSplit.Length; j++)
                    {
                        doubleArray[(i * 3) + j] = Convert.ToDouble(RowSplit[j]);
                    }

                }

                Param = doubleArray;
                EDMReturnCode Return = m_DMInterfaceScorpioPositionCorrection.ExecuteFunction(SquareCompParamID, Param);
                if (Return != EDMReturnCode.DM_SUCCESS)
                {
                    MessageBox.Show("Error in writing SquarenessComp : " + Return.ToString());
                    txtReturn.Text = Return.ToString();
                    //Application.Exit();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in Reading SquarenessComp from HUB : " + ex.Message);
                Environment.Exit(0);
            }
        }

        private void WriteToHUB_MetrologyFrame(object sender, EventArgs e)
        {
            try
            {
                object Param = null;
                int Count = 1;
                int MetrologyFrameParamNum = 22;

                RichTextBox MetrologyDataTextBoxName = txtRadiiB;

                short NumItems = 6;
                string[] RowSplit;

                double[] doubleArray = new double[NumItems];

                for (; Count <= 6; Count++, MetrologyFrameParamNum++) // First 6 rows of Metrology Frame Definition
                {
                    switch (Count)
                    {
                        case 1: MetrologyDataTextBoxName = txtRadiiB;
                            break;
                        case 2: MetrologyDataTextBoxName = txtAnglesB;
                            break;
                        case 3: MetrologyDataTextBoxName = txtVertOffsetsB;
                            break;
                        case 4: MetrologyDataTextBoxName = txtRadiiP;
                            break;
                        case 5: MetrologyDataTextBoxName = txtAnglesP;
                            break;
                        case 6: MetrologyDataTextBoxName = txtVertOffsetsP;
                            break;
                    }

                    if ((MetrologyDataTextBoxName.Text == null) || (MetrologyDataTextBoxName.Text == ""))
                    {
                        //MessageBox.Show("Transduction Frame Geom is NULL");
                        //return;
                        continue;
                    }

                    RowSplit = MetrologyDataTextBoxName.Text.Split(':');
                    if (RowSplit.Length != 6)
                    {
                        MessageBox.Show("Some invalid data for Transduction Frame Geom");
                        continue;
                    }
                    for (var j = 0; j < RowSplit.Length; j++)
                    {
                        doubleArray[j] = Convert.ToDouble(RowSplit[j]);
                    }

                    Param = doubleArray;
                    EDMReturnCode Return = m_DMInterfacexyzToHexapod.SetParameter(MetrologyFrameParamNum, Param);
                    if (Return != EDMReturnCode.DM_SUCCESS)
                    {
                        MessageBox.Show("Parameter Setting Failed for Transduction Frame Geom : " + Return.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in Writing Transduction Frame Geom to HUB : " + ex.Message);
                Environment.Exit(0);
            }
        }


        private void cmdWriteToHUB_CLick(object sender, EventArgs e)
        {
            WriteToHUB_StrutOffset(sender, e);
            WriteToHUB_StrutSlope(sender, e);
            WriteToHUB_StrutSerialNum(sender, e);
            WriteToHUB_SquareComp(sender, e);
            WriteToHUB_MetrologyFrame(sender, e);
        }

        private void ReadFromHUB_StrutOffset(object sender, EventArgs e)
        {
            object Param = null;
            int Count = 1;
            int StrutOffsetParamNum = 3;
            string StrutName = "Strut" + Count.ToString();
            TextBox StrutOffestTextBoxName = txtStrut1Offset;
            DemandModifierInterface m_DMInterface = m_DMInterfaceStrutErrorMapDM1;

            for (; Count <= 6; Count++) // All 6 struts
            {
                StrutName = "Strut" + Count.ToString();

                switch (Count)
                {
                    case 1: StrutOffestTextBoxName = txtStrut1Offset;
                        m_DMInterface = m_DMInterfaceStrutErrorMapDM1;
                        break;
                    case 2: StrutOffestTextBoxName = txtStrut2Offset;
                        m_DMInterface = m_DMInterfaceStrutErrorMapDM2;
                        break;
                    case 3: StrutOffestTextBoxName = txtStrut3Offset;
                        m_DMInterface = m_DMInterfaceStrutErrorMapDM3;
                        break;
                    case 4: StrutOffestTextBoxName = txtStrut4Offset;
                        m_DMInterface = m_DMInterfaceStrutErrorMapDM4;
                        break;
                    case 5: StrutOffestTextBoxName = txtStrut5Offset;
                        m_DMInterface = m_DMInterfaceStrutErrorMapDM5;
                        break;
                    case 6: StrutOffestTextBoxName = txtStrut6Offset;
                        m_DMInterface = m_DMInterfaceStrutErrorMapDM6;
                        break;
                }

                try
                {
                    StrutOffestTextBoxName.Clear();
                    EDMReturnCode Return = m_DMInterface.GetParameter(StrutOffsetParamNum, out Param);
                    if (Return != EDMReturnCode.DM_SUCCESS)
                    {
                        //MessageBox.Show("Parameter Getting Failed In " + StrutName + " StrutOffset : " + Return.ToString());
                        StrutOffestTextBoxName.Text = Return.ToString();
                    }
                    else if (Param == null)
                    {
                        //MessageBox.Show("Parameter " + StrutName + " StrutOffset : is NULL");
                        //StrutOffestTextBoxName.Text = "NULL";// Return.ToString();
                    }
                    else
                    {

                        Type RetType = Param.GetType();

                        if (Object.ReferenceEquals(RetType, typeof(double)))
                        {
                            double Value = (double)Param;
                            StrutOffestTextBoxName.Text = Value.ToString();
                        }
                        else
                        {
                            //MessageBox.Show("Invalid Parameter. Getting Failed In " + StrutName + " StrutOffset : " + Return.ToString());
                            StrutOffestTextBoxName.Text = Param.ToString();
                            //Application.Exit();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("In " + StrutName + " StrutOffset : " + ex.Message);
                    Environment.Exit(0);
                }
            }
        }

        private void ReadFromHUB_StrutSlope(object sender, EventArgs e)
        {
            object Param = null;
            int Count = 1;
            int StrutSlopeParamNum = 4;
            string StrutName = "Strut" + Count.ToString();
            TextBox StrutSlopeTextBoxName = txtStrut1Slope;
            DemandModifierInterface m_DMInterface = m_DMInterfaceStrutErrorMapDM1;

            for (; Count <= 6; Count++) // All 6 struts
            {
                StrutName = "Strut" + Count.ToString();

                switch (Count)
                {
                    case 1: StrutSlopeTextBoxName = txtStrut1Slope;
                        m_DMInterface = m_DMInterfaceStrutErrorMapDM1;
                        break;
                    case 2: StrutSlopeTextBoxName = txtStrut2Slope;
                        m_DMInterface = m_DMInterfaceStrutErrorMapDM2;
                        break;
                    case 3: StrutSlopeTextBoxName = txtStrut3Slope;
                        m_DMInterface = m_DMInterfaceStrutErrorMapDM3;
                        break;
                    case 4: StrutSlopeTextBoxName = txtStrut4Slope;
                        m_DMInterface = m_DMInterfaceStrutErrorMapDM4;
                        break;
                    case 5: StrutSlopeTextBoxName = txtStrut5Slope;
                        m_DMInterface = m_DMInterfaceStrutErrorMapDM5;
                        break;
                    case 6: StrutSlopeTextBoxName = txtStrut6Slope;
                        m_DMInterface = m_DMInterfaceStrutErrorMapDM6;
                        break;
                }

                try
                {
                    StrutSlopeTextBoxName.Clear();
                    EDMReturnCode Return = m_DMInterface.GetParameter(StrutSlopeParamNum, out Param);
                    if (Return != EDMReturnCode.DM_SUCCESS)
                    {
                        //MessageBox.Show("Parameter Getting Failed In " + StrutName + " StrutSlope : " + Return.ToString());
                        StrutSlopeTextBoxName.Text = Return.ToString();
                        //Application.Exit();
                    }
                    else if (Param == null)
                    {
                        //MessageBox.Show("Parameter " + StrutName + " StrutSlope : is NULL");
                        //StrutSlopeTextBoxName.Text = "NULL";// Return.ToString();
                    }
                    else
                    {
                        Type RetType = Param.GetType();

                        if (Object.ReferenceEquals(RetType, typeof(double)))
                        {
                            double Value = (double)Param;
                            StrutSlopeTextBoxName.Text = Value.ToString();
                        }
                        else
                        {
                            //MessageBox.Show("Invalid Parameter. Getting Failed In " + StrutName + " StrutSlope : " + Return.ToString());
                            StrutSlopeTextBoxName.Text = Param.ToString();
                            //Application.Exit();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("In " + StrutName + " StrutSlope : " + ex.Message);
                    Environment.Exit(0);
                }
            }
        }

        private void ReadFromHUB_StrutSerialNum(object sender, EventArgs e)
        {
            object Param = null;
            int Count = 1;
            int StrutSerialNumParamID = 10;
            string StrutName = "Strut" + Count.ToString();
            RichTextBox StrutSerialNumTextBoxName = txtStrut1SerialNum;

            for (; Count <= 6; Count++, StrutSerialNumParamID++) // All 6 struts
            {
                StrutName = "Strut" + Count.ToString();

                switch (Count)
                {
                    case 1: StrutSerialNumTextBoxName = txtStrut1SerialNum;
                        break;
                    case 2: StrutSerialNumTextBoxName = txtStrut2SerialNum;
                        break;
                    case 3: StrutSerialNumTextBoxName = txtStrut3SerialNum;
                        break;
                    case 4: StrutSerialNumTextBoxName = txtStrut4SerialNum;
                        break;
                    case 5: StrutSerialNumTextBoxName = txtStrut5SerialNum;
                        break;
                    case 6: StrutSerialNumTextBoxName = txtStrut6SerialNum;
                        break;
                }

                try
                {
                    StrutSerialNumTextBoxName.Clear();
                    EHIReturnCode Return = m_HWInterfaceHubEEPROM.GetParameter(StrutSerialNumParamID, out Param);
                    if (Return != EHIReturnCode.HI_SUCCESS)
                    {
                        //MessageBox.Show("Parameter Getting Failed In " + StrutName + " StrutSerial Number : " + Return.ToString());
                        StrutSerialNumTextBoxName.Text = Return.ToString();
                        //Application.Exit();
                    }
                    else if (Param == null)
                    {
                        //MessageBox.Show("Parameter " + StrutName + " StrutSerial Number : is NULL");
                        StrutSerialNumTextBoxName.Text = "NULL";// Return.ToString();
                    }
                    else
                    {
                        Type RetType = Param.GetType();

                        if (Object.ReferenceEquals(RetType, typeof(string)))
                        {
                            string Value = (string)Param;
                            StrutSerialNumTextBoxName.Text = Value.ToString();
                        }
                        else
                        {
                            //MessageBox.Show("Invalid Parameter. Getting Failed In " + StrutName + " StrutSerial Number : " + Return.ToString());
                            StrutSerialNumTextBoxName.Text = Param.ToString();
                            //Application.Exit();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("In " + StrutName + " StrutSerial Number : " + ex.Message);
                    Environment.Exit(0);
                }
            }
        }

        private void ReadFromHUB_SquareComp(object sender, EventArgs e)
        {
            try
            {
                txtSquareCompR0.Clear();
                txtSquareCompR1.Clear();
                txtSquareCompR2.Clear();

                object Param = null;
                int SquareCompParamID = 20010;
                TextBox SqCompRow = txtSquareCompR0;

                EDMReturnCode Return = m_DMInterfaceScorpioPositionCorrection.GetParameter(SquareCompParamID, out Param);
                if (Return != EDMReturnCode.DM_SUCCESS)
                {
                    MessageBox.Show("Error in reading SquarenessComp : " + Return.ToString());
                    txtReturn.Text = Return.ToString();
                    //Application.Exit();
                }
                else if (Param == null)
                {
                    //MessageBox.Show("SquarenessComp is NULL");
                    //txtReturn.Text = Return.ToString();
                }
                else
                {
                    txtReturn.Text = Return.ToString();
                    double[] doubleArray = (double[])Param;

                    for (var i = 0; i <= 2; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                SqCompRow = txtSquareCompR0;
                                break;
                            case 1:
                                SqCompRow = txtSquareCompR1;
                                break;
                            case 2:
                                SqCompRow = txtSquareCompR2;
                                break;
                        }
                        for (var j = 0; j <= 2; j++)
                        {
                            SqCompRow.Text += doubleArray[(i * 3) + j].ToString();
                            if (j < 2) SqCompRow.Text += ":";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in Reading SquarenessComp from HUB : " + ex.Message);
                Environment.Exit(0);
            }
        }

        private void ReadFromHUB_MetrologyFrame(object sender, EventArgs e)
        {
            try
            {
                txtRadiiB.Clear();
                txtAnglesB.Clear();
                txtVertOffsetsB.Clear();
                txtRadiiP.Clear();
                txtAnglesP.Clear();
                txtVertOffsetsP.Clear();
                //txtInitialProbeOffset.Clear();

                int StrutSerialNumParamID = 22;
                int Count = 0;

                object Param = null;
                for (; StrutSerialNumParamID <= 27; StrutSerialNumParamID++, Count++)
                {

                    EDMReturnCode Return = m_DMInterfacexyzToHexapod.GetParameter(StrutSerialNumParamID, out Param);
                    if (Return != EDMReturnCode.DM_SUCCESS)
                    {
                        MessageBox.Show("Error in reading Transduction Frame Geom : " + Return.ToString());
                        txtReturn.Text = Return.ToString();
                        //Application.Exit();
                    }
                    else if (Param == null)
                    {
                        //MessageBox.Show("Transduction Frame Geom is NULL");
                        //txtReturn.Text = Return.ToString();
                    }
                    else
                    {
                        txtReturn.Text = Return.ToString();
                        double[] doubleArray = (double[])Param;

                        switch (StrutSerialNumParamID)
                        {
                            case 22:
                                for (var j = 0; j < 6; j++)
                                {
                                    txtRadiiB.Text += doubleArray[j].ToString();
                                    if (j < 5) txtRadiiB.Text += ":";
                                }
                                break;
                            case 23:
                                for (var j = 0; j < 6; j++)
                                {
                                    txtAnglesB.Text += doubleArray[j].ToString();
                                    if (j < 5) txtAnglesB.Text += ":";
                                }
                                break;
                            case 24:
                                for (var j = 0; j < 6; j++)
                                {
                                    txtVertOffsetsB.Text += doubleArray[j].ToString();
                                    if (j < 5) txtVertOffsetsB.Text += ":";
                                }
                                break;
                            case 25:
                                for (var j = 0; j < 6; j++)
                                {
                                    txtRadiiP.Text += doubleArray[j].ToString();
                                    if (j < 5) txtRadiiP.Text += ":";
                                }
                                break;
                            case 26:
                                for (var j = 0; j < 6; j++)
                                {
                                    txtAnglesP.Text += doubleArray[j].ToString();
                                    if (j < 5) txtAnglesP.Text += ":";
                                }
                                break;
                            case 27:
                                for (var j = 0; j < 6; j++)
                                {
                                    txtVertOffsetsP.Text += doubleArray[j].ToString();
                                    if (j < 5) txtVertOffsetsP.Text += ":";
                                }
                                break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in Reading Transduction Frame Geom from HUB : " + ex.Message);
                Environment.Exit(0);
            }
        }

        private void cmdReadFromHUB_CLick(object sender, EventArgs e)
        {
            ReadFromHUB_StrutOffset(sender, e);
            ReadFromHUB_StrutSlope(sender, e);
            ReadFromHUB_StrutSerialNum(sender, e);
            ReadFromHUB_SquareComp(sender, e);
            ReadFromHUB_MetrologyFrame(sender, e);
        }

        private void SaveToFile(object sender, EventArgs e)
        {
            
            SaveFileDialog dlgSaveFile = new SaveFileDialog();
            dlgSaveFile.ShowDialog();
            string outputFileName = dlgSaveFile.FileName;
            

            try
            {
                List<string> existingLines = new List<string>();

                if (File.Exists(outputFileName))
                {
                    existingLines.AddRange(File.ReadAllLines(outputFileName));
                }

                using (StreamWriter writer = new StreamWriter(outputFileName))
                {
                    string TransductionFrameGeomValue = '"'+"[" + GetValueFromSection("[xyzToHexapodDM]", "TransductionFrameGeom", existingLines) + "]"+'"';
                    //Console.WriteLine(TransductionFrameGeomValue);

                    //All StrutErrorMapDM1-6
                    UpdateOrAddParameter(ref existingLines, "[StrutErrorMapDM1]", "StrutOffset=", "txtStrut1Offset");
                    UpdateOrAddParameter(ref existingLines, "[StrutErrorMapDM1]", "StrutSlope=", "txtStrut1Slope");

                    UpdateOrAddParameter(ref existingLines, "[StrutErrorMapDM2]", "StrutOffset=", "txtStrut2Offset");
                    UpdateOrAddParameter(ref existingLines, "[StrutErrorMapDM2]", "StrutSlope=", "txtStrut2Slope");

                    UpdateOrAddParameter(ref existingLines, "[StrutErrorMapDM3]", "StrutOffset=", "txtStrut3Offset");
                    UpdateOrAddParameter(ref existingLines, "[StrutErrorMapDM3]", "StrutSlope=", "txtStrut3Slope");

                    UpdateOrAddParameter(ref existingLines, "[StrutErrorMapDM4]", "StrutOffset=", "txtStrut4Offset");
                    UpdateOrAddParameter(ref existingLines, "[StrutErrorMapDM4]", "StrutSlope=", "txtStrut4Slope");

                    UpdateOrAddParameter(ref existingLines, "[StrutErrorMapDM5]", "StrutOffset=", "txtStrut5Offset");
                    UpdateOrAddParameter(ref existingLines, "[StrutErrorMapDM5]", "StrutSlope=", "txtStrut5Slope");

                    UpdateOrAddParameter(ref existingLines, "[StrutErrorMapDM6]", "StrutOffset=", "txtStrut6Offset");
                    UpdateOrAddParameter(ref existingLines, "[StrutErrorMapDM6]", "StrutSlope=", "txtStrut6Slope");

                    //All ScorpioSquarenessCompAlgorithm
                    UpdateOrAddParameter(ref existingLines, "[SquarenessCompDM]", "R0CompensationValues=", "txtSquareCompR0");
                    UpdateOrAddParameter(ref existingLines, "[SquarenessCompDM]", "R1CompensationValues=", "txtSquareCompR1");
                    UpdateOrAddParameter(ref existingLines, "[SquarenessCompDM]", "R2CompensationValues=", "txtSquareCompR2");

                    //All SquarenessCompDM
                    UpdateOrAddParameter(ref existingLines, TransductionFrameGeomValue, "RadiiB=", "txtRadiiB");
                    UpdateOrAddParameter(ref existingLines, TransductionFrameGeomValue, "RadiiB=", "txtRadiiB");
                    //Console.WriteLine(TransductionFrameGeomValue);
                    UpdateOrAddParameter(ref existingLines, TransductionFrameGeomValue, "AnglesB=", "txtAnglesB");
                    UpdateOrAddParameter(ref existingLines, TransductionFrameGeomValue, "VertOffsetsB=", "txtVertOffsetsB");
                    UpdateOrAddParameter(ref existingLines, TransductionFrameGeomValue, "RadiiP=", "txtRadiiP");
                    UpdateOrAddParameter(ref existingLines, TransductionFrameGeomValue, "AnglesP=", "txtAnglesP");
                    UpdateOrAddParameter(ref existingLines, TransductionFrameGeomValue, "VertOffsetsP=", "txtVertOffsetsP");

                    foreach (string line in existingLines)
                    {
                        writer.WriteLine(line);
                    }
                   
                    Console.WriteLine("Data written to the INI file successfully!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while writing to the INI file: " + ex.Message);
            }
        }

        private string GetValueFromSection(string sectionHeader, string key, List<string> lines)
        {
            bool sectionExists = false;
            bool desiredValueFound = false;
            string desiredValue = null;

            foreach (string line in lines)
            {
                if (line.StartsWith("[") && line.EndsWith("]"))
                {
                    // Check if the section header matches
                    if (line.Equals(sectionHeader, StringComparison.OrdinalIgnoreCase))
                    {
                        sectionExists = true;
                    }
                    else
                    {
                        sectionExists = false;
                    }
                }

                if (sectionExists && desiredValueFound == false)
                {
                    int delimiterIndex = line.IndexOf('=');
                    if (delimiterIndex != -1 && delimiterIndex < line.Length - 1)
                    {
                        string lineKey = line.Substring(0, delimiterIndex).Trim();
                        string lineValue = line.Substring(delimiterIndex + 1).Trim();

                        if (lineKey.Equals(key, StringComparison.OrdinalIgnoreCase))
                        {
                            desiredValue = lineValue;
                            desiredValueFound = true;
                        }
                    }
                }
            }

            return desiredValue;
        }

        private void UpdateOrAddParameter(ref List<string> lines, string sectionHeader, string parameter, string textBoxName)
        {
            string value = GetTextBoxValue(textBoxName);
            bool sectionExists = false;
            bool parameterExists = false;
            int sectionIndex = -1;

            // Find the section header in the existing lines
            for (int i = 0; i < lines.Count; i++)
            {
                if (lines[i].StartsWith(sectionHeader))
                {
                    sectionExists = true;
                    sectionIndex = i;
                    break;
                }
            }

            if (sectionExists)
            {
                // Search for the parameter in the section
                for (int i = sectionIndex + 1; i < lines.Count; i++)
                {
                    if (lines[i].StartsWith(parameter))
                    {
                        // Update the existing parameter value
                        lines[i] = parameter + value;
                        parameterExists = true;
                        break;
                    }
                }
            }

            if (!parameterExists)
            {
                // Find the index where the new parameter should be inserted
                int insertIndex = sectionExists ? sectionIndex + 1 : lines.Count;

                // Find the index of the next section header or the end of the file
                int endIndex = lines.FindIndex(insertIndex, line => line.StartsWith("[") || line == "");

                if (endIndex != -1)
                {
                    // Insert the new parameter before the next section header or end of file
                    lines.Insert(endIndex, parameter + value);
                }
                else
                {
                    // If no section header is found after the last parameter, add the new parameter at the end of the file
                    lines.Add(parameter + value);
                }
            }
        }

        private string GetTextBoxValue(string textBoxName)
        {
            Control textBox = Controls.Find(textBoxName, true).FirstOrDefault();

            if (textBox != null && textBox is TextBox)
            {
                return ((TextBox)textBox).Text;
            }

            return string.Empty;
        }




        private void cmdWriteOutputFile_CLick(object sender, EventArgs e)
        {
            SaveToFile(sender, e);
        }

        private void ReadFromFile(object sender, EventArgs e)
        {
            OpenFileDialog dlgOpenFile = new OpenFileDialog();
            dlgOpenFile.ShowDialog();
            string inputFileName = dlgOpenFile.FileName;

            try
            {
                if (File.Exists(inputFileName))
                {
                    using (StreamReader reader = new StreamReader(inputFileName))
                    {
                        string line = reader.ReadLine();

                        for (int i = 1; i <= 6; i++)
                        {
                            string sectionHeader = "StrutErrorMapDM" + i;
                            while (line != null && !line.StartsWith("[" + sectionHeader + "]"))
                            {
                                line = reader.ReadLine();
                            }
                            line = reader.ReadLine();

                            while (line != null && !line.StartsWith("["))
                            {
                                if (line.StartsWith("StrutOffset="))
                                {
                                    switch (i)
                                    {
                                        case 1:
                                            txtStrut1Offset.Text = line.Substring("StrutOffset=".Length);
                                            break;
                                        case 2:
                                            txtStrut2Offset.Text = line.Substring("StrutOffset=".Length);
                                            break;
                                        case 3:
                                            txtStrut3Offset.Text = line.Substring("StrutOffset=".Length);
                                            break;
                                        case 4:
                                            txtStrut4Offset.Text = line.Substring("StrutOffset=".Length);
                                            break;
                                        case 5:
                                            txtStrut5Offset.Text = line.Substring("StrutOffset=".Length);
                                            break;
                                        case 6:
                                            txtStrut6Offset.Text = line.Substring("StrutOffset=".Length);
                                            break;
                                    }
                                }
                                else if (line.StartsWith("StrutSlope="))
                                {
                                    switch (i)
                                    {
                                        case 1:
                                            txtStrut1Slope.Text = line.Substring("StrutSlope=".Length);
                                            break;
                                        case 2:
                                            txtStrut2Slope.Text = line.Substring("StrutSlope=".Length);
                                            break;
                                        case 3:
                                            txtStrut3Slope.Text = line.Substring("StrutSlope=".Length);
                                            break;
                                        case 4:
                                            txtStrut4Slope.Text = line.Substring("StrutSlope=".Length);
                                            break;
                                        case 5:
                                            txtStrut5Slope.Text = line.Substring("StrutSlope=".Length);
                                            break;
                                        case 6:
                                            txtStrut6Slope.Text = line.Substring("StrutSlope=".Length);
                                            break;
                                    }
                                }
                                else if (line.StartsWith("StrutSerialNo="))
                                {
                                    switch (i)
                                    {
                                        case 1:
                                            txtStrut1SerialNum.Text = line.Substring("StrutSerialNo=".Length);
                                            break;
                                        case 2:
                                            txtStrut2SerialNum.Text = line.Substring("StrutSerialNo=".Length);
                                            break;
                                        case 3:
                                            txtStrut3SerialNum.Text = line.Substring("StrutSerialNo=".Length);
                                            break;
                                        case 4:
                                            txtStrut4SerialNum.Text = line.Substring("StrutSerialNo=".Length);
                                            break;
                                        case 5:
                                            txtStrut5SerialNum.Text = line.Substring("StrutSerialNo=".Length);
                                            break;
                                        case 6:
                                            txtStrut6SerialNum.Text = line.Substring("StrutSerialNo=".Length);
                                            break;
                                    }
                                }

                                line = reader.ReadLine();
                            }
                        }
                    }
                }
                else
                {
                    Console.WriteLine("The file does not exist in the specified location.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error while reading from INI file: " + ex.Message);
            }
        }

        private void cmdReadInputFile_CLick(object sender, EventArgs e)
        {
            ReadFromFile(sender, e);
        }

    }
}
