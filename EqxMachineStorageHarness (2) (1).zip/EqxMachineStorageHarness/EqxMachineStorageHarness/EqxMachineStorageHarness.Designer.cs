﻿namespace EqxMachineStorageHarness
{
   partial class EqxMachineStorageHarness
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.cmbControllerID = new System.Windows.Forms.ComboBox();
         this.lblControllerID = new System.Windows.Forms.Label();
         this.btnConnect = new System.Windows.Forms.Button();
         this.btnReadInputFile = new System.Windows.Forms.Button();
         this.btnReadFromHUB = new System.Windows.Forms.Button();
         this.btnWriteOutputFile = new System.Windows.Forms.Button();
         this.btnWriteToHUB = new System.Windows.Forms.Button();
         this.lblStrut1 = new System.Windows.Forms.Label();
         this.lblStrut2 = new System.Windows.Forms.Label();
         this.lblStrut3 = new System.Windows.Forms.Label();
         this.lblStrut4 = new System.Windows.Forms.Label();
         this.lblStrut5 = new System.Windows.Forms.Label();
         this.lblStrut6 = new System.Windows.Forms.Label();
         this.lblStrutOffset = new System.Windows.Forms.Label();
         this.lblStrutSlope = new System.Windows.Forms.Label();
         this.lblStrutSerialNum = new System.Windows.Forms.Label();
         this.txtStrut1Offset = new System.Windows.Forms.TextBox();
         this.txtStrut2Offset = new System.Windows.Forms.TextBox();
         this.txtStrut3Offset = new System.Windows.Forms.TextBox();
         this.txtStrut4Offset = new System.Windows.Forms.TextBox();
         this.txtStrut5Offset = new System.Windows.Forms.TextBox();
         this.txtStrut6Offset = new System.Windows.Forms.TextBox();
         this.txtStrut1Slope = new System.Windows.Forms.TextBox();
         this.txtStrut2Slope = new System.Windows.Forms.TextBox();
         this.txtStrut3Slope = new System.Windows.Forms.TextBox();
         this.txtStrut4Slope = new System.Windows.Forms.TextBox();
         this.txtStrut5Slope = new System.Windows.Forms.TextBox();
         this.txtStrut6Slope = new System.Windows.Forms.TextBox();
         this.txtStrut1SerialNum = new System.Windows.Forms.RichTextBox();
         this.txtStrut2SerialNum = new System.Windows.Forms.RichTextBox();
         this.txtStrut3SerialNum = new System.Windows.Forms.RichTextBox();
         this.txtStrut4SerialNum = new System.Windows.Forms.RichTextBox();
         this.txtStrut5SerialNum = new System.Windows.Forms.RichTextBox();
         this.txtStrut6SerialNum = new System.Windows.Forms.RichTextBox();
         this.txtReturn = new System.Windows.Forms.TextBox();
         this.lblReturn = new System.Windows.Forms.Label();
         this.lblRadiiB = new System.Windows.Forms.Label();
         this.txtRadiiB = new System.Windows.Forms.RichTextBox();
         this.lblAnglesB = new System.Windows.Forms.Label();
         this.txtAnglesB = new System.Windows.Forms.RichTextBox();
         this.txtRadiiP = new System.Windows.Forms.RichTextBox();
         this.lblRadiiP = new System.Windows.Forms.Label();
         this.txtVertOffsetsB = new System.Windows.Forms.RichTextBox();
         this.lblVertOffsetsB = new System.Windows.Forms.Label();
         this.txtVertOffsetsP = new System.Windows.Forms.RichTextBox();
         this.lblVertOffsetsP = new System.Windows.Forms.Label();
         this.txtAnglesP = new System.Windows.Forms.RichTextBox();
         this.lblAnglesP = new System.Windows.Forms.Label();
         this.lblSquareComp = new System.Windows.Forms.Label();
         this.txtSquareCompR0 = new System.Windows.Forms.TextBox();
         this.txtSquareCompR1 = new System.Windows.Forms.TextBox();
         this.txtSquareCompR2 = new System.Windows.Forms.TextBox();
         this.SuspendLayout();
         // 
         // cmbControllerID
         // 
         this.cmbControllerID.FormattingEnabled = true;
         this.cmbControllerID.Location = new System.Drawing.Point(131, 12);
         this.cmbControllerID.Name = "cmbControllerID";
         this.cmbControllerID.Size = new System.Drawing.Size(121, 21);
         this.cmbControllerID.TabIndex = 0;
         // 
         // lblControllerID
         // 
         this.lblControllerID.AutoSize = true;
         this.lblControllerID.Location = new System.Drawing.Point(49, 15);
         this.lblControllerID.Name = "lblControllerID";
         this.lblControllerID.Size = new System.Drawing.Size(65, 13);
         this.lblControllerID.TabIndex = 1;
         this.lblControllerID.Text = "ControllerID:";
         // 
         // btnConnect
         // 
         this.btnConnect.Location = new System.Drawing.Point(289, 12);
         this.btnConnect.Name = "btnConnect";
         this.btnConnect.Size = new System.Drawing.Size(94, 32);
         this.btnConnect.TabIndex = 2;
         this.btnConnect.Text = "Connect";
         this.btnConnect.UseVisualStyleBackColor = true;
         this.btnConnect.Click += new System.EventHandler(this.cmdConnect_Click);
         // 
         // btnReadInputFile
         // 
         this.btnReadInputFile.Location = new System.Drawing.Point(12, 49);
         this.btnReadInputFile.Name = "btnReadInputFile";
         this.btnReadInputFile.Size = new System.Drawing.Size(106, 50);
         this.btnReadInputFile.TabIndex = 3;
         this.btnReadInputFile.Text = "ReadInputFile";
         this.btnReadInputFile.UseVisualStyleBackColor = true;
         this.btnReadInputFile.Click += new System.EventHandler(this.cmdReadInputFile_CLick);
         // 
         // btnReadFromHUB
         // 
         this.btnReadFromHUB.Location = new System.Drawing.Point(131, 49);
         this.btnReadFromHUB.Name = "btnReadFromHUB";
         this.btnReadFromHUB.Size = new System.Drawing.Size(106, 50);
         this.btnReadFromHUB.TabIndex = 4;
         this.btnReadFromHUB.Text = "ReadFromHUB";
         this.btnReadFromHUB.UseVisualStyleBackColor = true;
         this.btnReadFromHUB.Click += new System.EventHandler(this.cmdReadFromHUB_CLick);
         // 
         // btnWriteOutputFile
         // 
         this.btnWriteOutputFile.Location = new System.Drawing.Point(252, 50);
         this.btnWriteOutputFile.Name = "btnWriteOutputFile";
         this.btnWriteOutputFile.Size = new System.Drawing.Size(106, 50);
         this.btnWriteOutputFile.TabIndex = 5;
         this.btnWriteOutputFile.Text = "WriteOutputFile";
         this.btnWriteOutputFile.UseVisualStyleBackColor = true;
         this.btnWriteOutputFile.Click += new System.EventHandler(this.cmdWriteOutputFile_CLick);
         // 
         // btnWriteToHUB
         // 
         this.btnWriteToHUB.Location = new System.Drawing.Point(375, 49);
         this.btnWriteToHUB.Name = "btnWriteToHUB";
         this.btnWriteToHUB.Size = new System.Drawing.Size(106, 50);
         this.btnWriteToHUB.TabIndex = 6;
         this.btnWriteToHUB.Text = "WriteToHUB";
         this.btnWriteToHUB.UseVisualStyleBackColor = true;
         this.btnWriteToHUB.Click += new System.EventHandler(this.cmdWriteToHUB_CLick);
         // 
         // lblStrut1
         // 
         this.lblStrut1.AutoSize = true;
         this.lblStrut1.Location = new System.Drawing.Point(127, 125);
         this.lblStrut1.Name = "lblStrut1";
         this.lblStrut1.Size = new System.Drawing.Size(35, 13);
         this.lblStrut1.TabIndex = 7;
         this.lblStrut1.Text = "Strut1";
         // 
         // lblStrut2
         // 
         this.lblStrut2.AutoSize = true;
         this.lblStrut2.Location = new System.Drawing.Point(215, 125);
         this.lblStrut2.Name = "lblStrut2";
         this.lblStrut2.Size = new System.Drawing.Size(35, 13);
         this.lblStrut2.TabIndex = 8;
         this.lblStrut2.Text = "Strut2";
         // 
         // lblStrut3
         // 
         this.lblStrut3.AutoSize = true;
         this.lblStrut3.Location = new System.Drawing.Point(314, 125);
         this.lblStrut3.Name = "lblStrut3";
         this.lblStrut3.Size = new System.Drawing.Size(35, 13);
         this.lblStrut3.TabIndex = 9;
         this.lblStrut3.Text = "Strut3";
         // 
         // lblStrut4
         // 
         this.lblStrut4.AutoSize = true;
         this.lblStrut4.Location = new System.Drawing.Point(412, 125);
         this.lblStrut4.Name = "lblStrut4";
         this.lblStrut4.Size = new System.Drawing.Size(35, 13);
         this.lblStrut4.TabIndex = 10;
         this.lblStrut4.Text = "Strut4";
         // 
         // lblStrut5
         // 
         this.lblStrut5.AutoSize = true;
         this.lblStrut5.Location = new System.Drawing.Point(499, 125);
         this.lblStrut5.Name = "lblStrut5";
         this.lblStrut5.Size = new System.Drawing.Size(35, 13);
         this.lblStrut5.TabIndex = 11;
         this.lblStrut5.Text = "Strut5";
         // 
         // lblStrut6
         // 
         this.lblStrut6.AutoSize = true;
         this.lblStrut6.Location = new System.Drawing.Point(594, 125);
         this.lblStrut6.Name = "lblStrut6";
         this.lblStrut6.Size = new System.Drawing.Size(35, 13);
         this.lblStrut6.TabIndex = 12;
         this.lblStrut6.Text = "Strut6";
         // 
         // lblStrutOffset
         // 
         this.lblStrutOffset.AutoSize = true;
         this.lblStrutOffset.Location = new System.Drawing.Point(12, 152);
         this.lblStrutOffset.Name = "lblStrutOffset";
         this.lblStrutOffset.Size = new System.Drawing.Size(57, 13);
         this.lblStrutOffset.TabIndex = 13;
         this.lblStrutOffset.Text = "StrutOffset";
         // 
         // lblStrutSlope
         // 
         this.lblStrutSlope.AutoSize = true;
         this.lblStrutSlope.Location = new System.Drawing.Point(12, 184);
         this.lblStrutSlope.Name = "lblStrutSlope";
         this.lblStrutSlope.Size = new System.Drawing.Size(56, 13);
         this.lblStrutSlope.TabIndex = 14;
         this.lblStrutSlope.Text = "StrutSlope";
         // 
         // lblStrutSerialNum
         // 
         this.lblStrutSerialNum.AutoSize = true;
         this.lblStrutSerialNum.Location = new System.Drawing.Point(12, 212);
         this.lblStrutSerialNum.Name = "lblStrutSerialNum";
         this.lblStrutSerialNum.Size = new System.Drawing.Size(77, 13);
         this.lblStrutSerialNum.TabIndex = 15;
         this.lblStrutSerialNum.Text = "StrutSerialNum";
         // 
         // txtStrut1Offset
         // 
         this.txtStrut1Offset.Location = new System.Drawing.Point(96, 151);
         this.txtStrut1Offset.Name = "txtStrut1Offset";
         this.txtStrut1Offset.Size = new System.Drawing.Size(77, 20);
         this.txtStrut1Offset.TabIndex = 16;
         // 
         // txtStrut2Offset
         // 
         this.txtStrut2Offset.Location = new System.Drawing.Point(188, 151);
         this.txtStrut2Offset.Name = "txtStrut2Offset";
         this.txtStrut2Offset.Size = new System.Drawing.Size(77, 20);
         this.txtStrut2Offset.TabIndex = 17;
         // 
         // txtStrut3Offset
         // 
         this.txtStrut3Offset.Location = new System.Drawing.Point(289, 151);
         this.txtStrut3Offset.Name = "txtStrut3Offset";
         this.txtStrut3Offset.Size = new System.Drawing.Size(77, 20);
         this.txtStrut3Offset.TabIndex = 18;
         // 
         // txtStrut4Offset
         // 
         this.txtStrut4Offset.Location = new System.Drawing.Point(387, 151);
         this.txtStrut4Offset.Name = "txtStrut4Offset";
         this.txtStrut4Offset.Size = new System.Drawing.Size(77, 20);
         this.txtStrut4Offset.TabIndex = 19;
         // 
         // txtStrut5Offset
         // 
         this.txtStrut5Offset.Location = new System.Drawing.Point(484, 151);
         this.txtStrut5Offset.Name = "txtStrut5Offset";
         this.txtStrut5Offset.Size = new System.Drawing.Size(77, 20);
         this.txtStrut5Offset.TabIndex = 20;
         // 
         // txtStrut6Offset
         // 
         this.txtStrut6Offset.Location = new System.Drawing.Point(579, 151);
         this.txtStrut6Offset.Name = "txtStrut6Offset";
         this.txtStrut6Offset.Size = new System.Drawing.Size(77, 20);
         this.txtStrut6Offset.TabIndex = 21;
         // 
         // txtStrut1Slope
         // 
         this.txtStrut1Slope.Location = new System.Drawing.Point(96, 182);
         this.txtStrut1Slope.Name = "txtStrut1Slope";
         this.txtStrut1Slope.Size = new System.Drawing.Size(76, 20);
         this.txtStrut1Slope.TabIndex = 22;
         // 
         // txtStrut2Slope
         // 
         this.txtStrut2Slope.Location = new System.Drawing.Point(188, 184);
         this.txtStrut2Slope.Name = "txtStrut2Slope";
         this.txtStrut2Slope.Size = new System.Drawing.Size(76, 20);
         this.txtStrut2Slope.TabIndex = 23;
         // 
         // txtStrut3Slope
         // 
         this.txtStrut3Slope.Location = new System.Drawing.Point(289, 184);
         this.txtStrut3Slope.Name = "txtStrut3Slope";
         this.txtStrut3Slope.Size = new System.Drawing.Size(76, 20);
         this.txtStrut3Slope.TabIndex = 24;
         // 
         // txtStrut4Slope
         // 
         this.txtStrut4Slope.Location = new System.Drawing.Point(387, 184);
         this.txtStrut4Slope.Name = "txtStrut4Slope";
         this.txtStrut4Slope.Size = new System.Drawing.Size(76, 20);
         this.txtStrut4Slope.TabIndex = 25;
         // 
         // txtStrut5Slope
         // 
         this.txtStrut5Slope.Location = new System.Drawing.Point(485, 182);
         this.txtStrut5Slope.Name = "txtStrut5Slope";
         this.txtStrut5Slope.Size = new System.Drawing.Size(76, 20);
         this.txtStrut5Slope.TabIndex = 26;
         // 
         // txtStrut6Slope
         // 
         this.txtStrut6Slope.Location = new System.Drawing.Point(579, 181);
         this.txtStrut6Slope.Name = "txtStrut6Slope";
         this.txtStrut6Slope.Size = new System.Drawing.Size(76, 20);
         this.txtStrut6Slope.TabIndex = 27;
         // 
         // txtStrut1SerialNum
         // 
         this.txtStrut1SerialNum.Location = new System.Drawing.Point(94, 214);
         this.txtStrut1SerialNum.Name = "txtStrut1SerialNum";
         this.txtStrut1SerialNum.Size = new System.Drawing.Size(77, 19);
         this.txtStrut1SerialNum.TabIndex = 28;
         this.txtStrut1SerialNum.Text = "";
         // 
         // txtStrut2SerialNum
         // 
         this.txtStrut2SerialNum.Location = new System.Drawing.Point(188, 214);
         this.txtStrut2SerialNum.Name = "txtStrut2SerialNum";
         this.txtStrut2SerialNum.Size = new System.Drawing.Size(77, 19);
         this.txtStrut2SerialNum.TabIndex = 29;
         this.txtStrut2SerialNum.Text = "";
         // 
         // txtStrut3SerialNum
         // 
         this.txtStrut3SerialNum.Location = new System.Drawing.Point(288, 214);
         this.txtStrut3SerialNum.Name = "txtStrut3SerialNum";
         this.txtStrut3SerialNum.Size = new System.Drawing.Size(77, 19);
         this.txtStrut3SerialNum.TabIndex = 30;
         this.txtStrut3SerialNum.Text = "";
         // 
         // txtStrut4SerialNum
         // 
         this.txtStrut4SerialNum.Location = new System.Drawing.Point(386, 212);
         this.txtStrut4SerialNum.Name = "txtStrut4SerialNum";
         this.txtStrut4SerialNum.Size = new System.Drawing.Size(77, 19);
         this.txtStrut4SerialNum.TabIndex = 31;
         this.txtStrut4SerialNum.Text = "";
         // 
         // txtStrut5SerialNum
         // 
         this.txtStrut5SerialNum.Location = new System.Drawing.Point(485, 211);
         this.txtStrut5SerialNum.Name = "txtStrut5SerialNum";
         this.txtStrut5SerialNum.Size = new System.Drawing.Size(77, 19);
         this.txtStrut5SerialNum.TabIndex = 32;
         this.txtStrut5SerialNum.Text = "";
         // 
         // txtStrut6SerialNum
         // 
         this.txtStrut6SerialNum.Location = new System.Drawing.Point(579, 209);
         this.txtStrut6SerialNum.Name = "txtStrut6SerialNum";
         this.txtStrut6SerialNum.Size = new System.Drawing.Size(77, 19);
         this.txtStrut6SerialNum.TabIndex = 33;
         this.txtStrut6SerialNum.Text = "";
         // 
         // txtReturn
         // 
         this.txtReturn.Location = new System.Drawing.Point(355, 506);
         this.txtReturn.Name = "txtReturn";
         this.txtReturn.Size = new System.Drawing.Size(240, 20);
         this.txtReturn.TabIndex = 34;
         // 
         // lblReturn
         // 
         this.lblReturn.AutoSize = true;
         this.lblReturn.Location = new System.Drawing.Point(310, 513);
         this.lblReturn.Name = "lblReturn";
         this.lblReturn.Size = new System.Drawing.Size(39, 13);
         this.lblReturn.TabIndex = 35;
         this.lblReturn.Text = "Return";
         // 
         // lblRadiiB
         // 
         this.lblRadiiB.AutoSize = true;
         this.lblRadiiB.Location = new System.Drawing.Point(24, 308);
         this.lblRadiiB.Name = "lblRadiiB";
         this.lblRadiiB.Size = new System.Drawing.Size(38, 13);
         this.lblRadiiB.TabIndex = 36;
         this.lblRadiiB.Text = "RadiiB";
         // 
         // txtRadiiB
         // 
         this.txtRadiiB.Location = new System.Drawing.Point(97, 302);
         this.txtRadiiB.Name = "txtRadiiB";
         this.txtRadiiB.Size = new System.Drawing.Size(414, 25);
         this.txtRadiiB.TabIndex = 37;
         this.txtRadiiB.Text = "";
         // 
         // lblAnglesB
         // 
         this.lblAnglesB.AutoSize = true;
         this.lblAnglesB.Location = new System.Drawing.Point(26, 339);
         this.lblAnglesB.Name = "lblAnglesB";
         this.lblAnglesB.Size = new System.Drawing.Size(46, 13);
         this.lblAnglesB.TabIndex = 38;
         this.lblAnglesB.Text = "AnglesB";
         // 
         // txtAnglesB
         // 
         this.txtAnglesB.Location = new System.Drawing.Point(97, 333);
         this.txtAnglesB.Name = "txtAnglesB";
         this.txtAnglesB.Size = new System.Drawing.Size(414, 25);
         this.txtAnglesB.TabIndex = 39;
         this.txtAnglesB.Text = "";
         // 
         // txtRadiiP
         // 
         this.txtRadiiP.Location = new System.Drawing.Point(97, 395);
         this.txtRadiiP.Name = "txtRadiiP";
         this.txtRadiiP.Size = new System.Drawing.Size(414, 25);
         this.txtRadiiP.TabIndex = 43;
         this.txtRadiiP.Text = "";
         // 
         // lblRadiiP
         // 
         this.lblRadiiP.AutoSize = true;
         this.lblRadiiP.Location = new System.Drawing.Point(26, 401);
         this.lblRadiiP.Name = "lblRadiiP";
         this.lblRadiiP.Size = new System.Drawing.Size(38, 13);
         this.lblRadiiP.TabIndex = 42;
         this.lblRadiiP.Text = "RadiiP";
         // 
         // txtVertOffsetsB
         // 
         this.txtVertOffsetsB.Location = new System.Drawing.Point(97, 364);
         this.txtVertOffsetsB.Name = "txtVertOffsetsB";
         this.txtVertOffsetsB.Size = new System.Drawing.Size(414, 25);
         this.txtVertOffsetsB.TabIndex = 41;
         this.txtVertOffsetsB.Text = "";
         // 
         // lblVertOffsetsB
         // 
         this.lblVertOffsetsB.AutoSize = true;
         this.lblVertOffsetsB.Location = new System.Drawing.Point(24, 370);
         this.lblVertOffsetsB.Name = "lblVertOffsetsB";
         this.lblVertOffsetsB.Size = new System.Drawing.Size(66, 13);
         this.lblVertOffsetsB.TabIndex = 40;
         this.lblVertOffsetsB.Text = "VertOffsetsB";
         // 
         // txtVertOffsetsP
         // 
         this.txtVertOffsetsP.Location = new System.Drawing.Point(96, 457);
         this.txtVertOffsetsP.Name = "txtVertOffsetsP";
         this.txtVertOffsetsP.Size = new System.Drawing.Size(415, 25);
         this.txtVertOffsetsP.TabIndex = 47;
         this.txtVertOffsetsP.Text = "";
         // 
         // lblVertOffsetsP
         // 
         this.lblVertOffsetsP.AutoSize = true;
         this.lblVertOffsetsP.Location = new System.Drawing.Point(25, 463);
         this.lblVertOffsetsP.Name = "lblVertOffsetsP";
         this.lblVertOffsetsP.Size = new System.Drawing.Size(66, 13);
         this.lblVertOffsetsP.TabIndex = 46;
         this.lblVertOffsetsP.Text = "VertOffsetsP";
         // 
         // txtAnglesP
         // 
         this.txtAnglesP.Location = new System.Drawing.Point(96, 426);
         this.txtAnglesP.Name = "txtAnglesP";
         this.txtAnglesP.Size = new System.Drawing.Size(415, 25);
         this.txtAnglesP.TabIndex = 45;
         this.txtAnglesP.Text = "";
         // 
         // lblAnglesP
         // 
         this.lblAnglesP.AutoSize = true;
         this.lblAnglesP.Location = new System.Drawing.Point(23, 432);
         this.lblAnglesP.Name = "lblAnglesP";
         this.lblAnglesP.Size = new System.Drawing.Size(46, 13);
         this.lblAnglesP.TabIndex = 44;
         this.lblAnglesP.Text = "AnglesP";
         // 
         // lblSquareComp
         // 
         this.lblSquareComp.AutoSize = true;
         this.lblSquareComp.Location = new System.Drawing.Point(93, 263);
         this.lblSquareComp.Name = "lblSquareComp";
         this.lblSquareComp.Size = new System.Drawing.Size(68, 13);
         this.lblSquareComp.TabIndex = 48;
         this.lblSquareComp.Text = "SquareComp";
         // 
         // txtSquareCompR0
         // 
         this.txtSquareCompR0.Location = new System.Drawing.Point(183, 237);
         this.txtSquareCompR0.Name = "txtSquareCompR0";
         this.txtSquareCompR0.Size = new System.Drawing.Size(183, 20);
         this.txtSquareCompR0.TabIndex = 49;
         // 
         // txtSquareCompR1
         // 
         this.txtSquareCompR1.Location = new System.Drawing.Point(183, 258);
         this.txtSquareCompR1.Name = "txtSquareCompR1";
         this.txtSquareCompR1.Size = new System.Drawing.Size(182, 20);
         this.txtSquareCompR1.TabIndex = 52;
         // 
         // txtSquareCompR2
         // 
         this.txtSquareCompR2.Location = new System.Drawing.Point(183, 279);
         this.txtSquareCompR2.Name = "txtSquareCompR2";
         this.txtSquareCompR2.Size = new System.Drawing.Size(183, 20);
         this.txtSquareCompR2.TabIndex = 55;
         // 
         // EqxMachineStorageHarness
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(692, 538);
         this.Controls.Add(this.txtSquareCompR2);
         this.Controls.Add(this.txtSquareCompR1);
         this.Controls.Add(this.txtSquareCompR0);
         this.Controls.Add(this.lblSquareComp);
         this.Controls.Add(this.txtVertOffsetsP);
         this.Controls.Add(this.lblVertOffsetsP);
         this.Controls.Add(this.txtAnglesP);
         this.Controls.Add(this.lblAnglesP);
         this.Controls.Add(this.txtRadiiP);
         this.Controls.Add(this.lblRadiiP);
         this.Controls.Add(this.txtVertOffsetsB);
         this.Controls.Add(this.lblVertOffsetsB);
         this.Controls.Add(this.txtAnglesB);
         this.Controls.Add(this.lblAnglesB);
         this.Controls.Add(this.txtRadiiB);
         this.Controls.Add(this.lblRadiiB);
         this.Controls.Add(this.lblReturn);
         this.Controls.Add(this.txtReturn);
         this.Controls.Add(this.txtStrut6SerialNum);
         this.Controls.Add(this.txtStrut5SerialNum);
         this.Controls.Add(this.txtStrut4SerialNum);
         this.Controls.Add(this.txtStrut3SerialNum);
         this.Controls.Add(this.txtStrut2SerialNum);
         this.Controls.Add(this.txtStrut1SerialNum);
         this.Controls.Add(this.txtStrut6Slope);
         this.Controls.Add(this.txtStrut5Slope);
         this.Controls.Add(this.txtStrut4Slope);
         this.Controls.Add(this.txtStrut3Slope);
         this.Controls.Add(this.txtStrut2Slope);
         this.Controls.Add(this.txtStrut1Slope);
         this.Controls.Add(this.txtStrut6Offset);
         this.Controls.Add(this.txtStrut5Offset);
         this.Controls.Add(this.txtStrut4Offset);
         this.Controls.Add(this.txtStrut3Offset);
         this.Controls.Add(this.txtStrut2Offset);
         this.Controls.Add(this.txtStrut1Offset);
         this.Controls.Add(this.lblStrutSerialNum);
         this.Controls.Add(this.lblStrutSlope);
         this.Controls.Add(this.lblStrutOffset);
         this.Controls.Add(this.lblStrut6);
         this.Controls.Add(this.lblStrut5);
         this.Controls.Add(this.lblStrut4);
         this.Controls.Add(this.lblStrut3);
         this.Controls.Add(this.lblStrut2);
         this.Controls.Add(this.lblStrut1);
         this.Controls.Add(this.btnWriteToHUB);
         this.Controls.Add(this.btnWriteOutputFile);
         this.Controls.Add(this.btnReadFromHUB);
         this.Controls.Add(this.btnReadInputFile);
         this.Controls.Add(this.btnConnect);
         this.Controls.Add(this.lblControllerID);
         this.Controls.Add(this.cmbControllerID);
         this.Name = "EqxMachineStorageHarness";
         this.Text = "Form1";
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      private System.Windows.Forms.ComboBox cmbControllerID;
      private System.Windows.Forms.Label lblControllerID;
      private System.Windows.Forms.Button btnConnect;
      private System.Windows.Forms.Button btnReadInputFile;
      private System.Windows.Forms.Button btnReadFromHUB;
      private System.Windows.Forms.Button btnWriteOutputFile;
      private System.Windows.Forms.Button btnWriteToHUB;
      private System.Windows.Forms.Label lblStrut1;
      private System.Windows.Forms.Label lblStrut2;
      private System.Windows.Forms.Label lblStrut3;
      private System.Windows.Forms.Label lblStrut4;
      private System.Windows.Forms.Label lblStrut5;
      private System.Windows.Forms.Label lblStrut6;
      private System.Windows.Forms.Label lblStrutOffset;
      private System.Windows.Forms.Label lblStrutSlope;
      private System.Windows.Forms.Label lblStrutSerialNum;
      private System.Windows.Forms.TextBox txtStrut1Offset;
      private System.Windows.Forms.TextBox txtStrut2Offset;
      private System.Windows.Forms.TextBox txtStrut3Offset;
      private System.Windows.Forms.TextBox txtStrut4Offset;
      private System.Windows.Forms.TextBox txtStrut5Offset;
      private System.Windows.Forms.TextBox txtStrut6Offset;
      private System.Windows.Forms.TextBox txtStrut1Slope;
      private System.Windows.Forms.TextBox txtStrut2Slope;
      private System.Windows.Forms.TextBox txtStrut3Slope;
      private System.Windows.Forms.TextBox txtStrut4Slope;
      private System.Windows.Forms.TextBox txtStrut5Slope;
      private System.Windows.Forms.TextBox txtStrut6Slope;
      private System.Windows.Forms.RichTextBox txtStrut1SerialNum;
      private System.Windows.Forms.RichTextBox txtStrut2SerialNum;
      private System.Windows.Forms.RichTextBox txtStrut3SerialNum;
      private System.Windows.Forms.RichTextBox txtStrut4SerialNum;
      private System.Windows.Forms.RichTextBox txtStrut5SerialNum;
      private System.Windows.Forms.RichTextBox txtStrut6SerialNum;
      private System.Windows.Forms.TextBox txtReturn;
      private System.Windows.Forms.Label lblReturn;
      private System.Windows.Forms.Label lblRadiiB;
      private System.Windows.Forms.RichTextBox txtRadiiB;
      private System.Windows.Forms.Label lblAnglesB;
      private System.Windows.Forms.RichTextBox txtAnglesB;
      private System.Windows.Forms.RichTextBox txtRadiiP;
      private System.Windows.Forms.Label lblRadiiP;
      private System.Windows.Forms.RichTextBox txtVertOffsetsB;
      private System.Windows.Forms.Label lblVertOffsetsB;
      private System.Windows.Forms.RichTextBox txtVertOffsetsP;
      private System.Windows.Forms.Label lblVertOffsetsP;
      private System.Windows.Forms.RichTextBox txtAnglesP;
      private System.Windows.Forms.Label lblAnglesP;
      private System.Windows.Forms.Label lblSquareComp;
      private System.Windows.Forms.TextBox txtSquareCompR0;
      private System.Windows.Forms.TextBox txtSquareCompR1;
      private System.Windows.Forms.TextBox txtSquareCompR2;

   }
}

